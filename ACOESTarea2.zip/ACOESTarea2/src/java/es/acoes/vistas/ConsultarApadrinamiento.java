/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.acoes.vistas;

import es.acoes.entidades.Apadrinamiento;
import es.acoes.entidades.CartasPaquetes;
import java.io.Serializable;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

/**
 *
 * @author Usuario
 */
@Named(value = "consultarApadrinamiento")
@SessionScoped
public class ConsultarApadrinamiento implements Serializable {
    
    private List<Apadrinamiento> ap;
    
    public ConsultarApadrinamiento() {
        
    }

    public List<Apadrinamiento> getEnvios() {
        return ap;
    }

    public void setApadrinamientos(List<Apadrinamiento> ap) {
        this.ap = ap;
    }
    
    
}
