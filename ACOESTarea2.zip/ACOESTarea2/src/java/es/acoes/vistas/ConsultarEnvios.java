/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.acoes.vistas;

import es.acoes.entidades.CartasPaquetes;
import java.io.Serializable;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

/**
 *
 * @author Usuario
 */
@Named(value = "consultarEnvios")
@SessionScoped
public class ConsultarEnvios implements Serializable {
    
    private List<CartasPaquetes> envios;
    
    public ConsultarEnvios() {
        
    }

    public List<CartasPaquetes> getEnvios() {
        return envios;
    }

    public void setEnvios(List<CartasPaquetes> envios) {
        this.envios = envios;
    }
    
    
}
